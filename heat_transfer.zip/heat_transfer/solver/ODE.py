from scipy.integrate import solve_ivp
from heat_transfer.thermal.heat import HeatSystem
from heat_transfer.functions.friction import DarcyFriction
from heat_transfer.fluid_props.GasProps import HotFlueGas
class FireTubeGasODE:

    def __init__(self, PassWithCalc, GasStreamWithCalc):
        self.q_ = HeatSystem.q_
        self.m_dot = GasStreamWithCalc.mass_flow_rate
        self.cp = HotFlueGas(GasStreamWithCalc).cp
        self.fD = DarcyFriction(GasStreamWithCalc, PassWithCalc).colebrook
        self.Di = PassWithCalc.geometry.inner_diameter
        self.G = GasStreamWithCalc.mass_flux
        self.rho = HotFlueGas(GasStreamWithCalc).density

    def rhs(self):
        dTdz = - self.q_ / (self.m_dot * self.cp)
        dpdz = - (self.fD / (2.0 * self.D_i)) * (self.G*self.G) / self.rho
        return [dTdz, dpdz]

    def solve(self, z_span, y0, method="BDF", **kwargs):
        return solve_ivp(self.rhs, z_span, y0, method=method, **kwargs)